Design canvas export

project/  the canvas's own files exactly as published (canvas.json index + one .dc.html per artboard). They need the Design canvas runtime (support.js) to run.
previews/ standalone HTML snapshots of each board that open in any browser (interactive boards show their opening state).
